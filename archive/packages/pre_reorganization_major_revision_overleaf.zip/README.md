# Overleaf/XeLaTeX package

Upload the contents of this directory to Overleaf and compile main.tex with
XeLaTeX.  The numbered article structure is:

1. Introduction
2. Copula-Based Mean-Reverting Markov Processes
3. Mean-Reverting Processes from Monotone Diffusion Transforms
4. Mean-Reverting Processes from Mixed Copula Families
5. Empirical Evidence from Kraken USDT/USD
6. Conclusion

Theory and proof sections are generated from the canonical
meanreversion_article_theory_revised.tex by
scripts/19_build_submission_paper.py.  Do not edit the generated theory.tex or
proofs.tex directly.  Empirical table fragments are generated from the
versioned CSV outputs listed in BUILD_MANIFEST.json.
