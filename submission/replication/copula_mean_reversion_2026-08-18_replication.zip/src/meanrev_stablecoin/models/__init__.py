"""Parametric and copula models."""

